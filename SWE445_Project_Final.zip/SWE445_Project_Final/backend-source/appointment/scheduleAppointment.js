const {
  patients,
  doctors,
  appointments,
  appointmentRequestLogs
} = require("./appointmentData");

const rateLimitStore = {};
const VALID_APPOINTMENT_AUTHORIZATION_PIN = "1234";

function logRequest(userId, patientId, outcomeStatus) {
  appointmentRequestLogs.push({
    request_log_id: appointmentRequestLogs.length + 1,
    user_id: userId,
    patient_id: patientId,
    action_type: "Schedule Appointment",
    request_time: new Date().toISOString(),
    outcome_status: outcomeStatus
  });
}

function checkRateLimit(userId) {
  const now = Date.now();
  const windowTime = 10 * 60 * 1000;
  const maxRequests = 5;

  if (!rateLimitStore[userId]) {
    rateLimitStore[userId] = [];
  }

  rateLimitStore[userId] = rateLimitStore[userId].filter(
    requestTime => now - requestTime < windowTime
  );

  if (rateLimitStore[userId].length >= maxRequests) {
    return false;
  }

  rateLimitStore[userId].push(now);
  return true;
}

function validateAppointmentData(patientId, doctorId, appointmentDateTime, reason) {
  if (!patientId || !doctorId || !appointmentDateTime || !reason) {
    return "All appointment fields are required.";
  }

  if (reason.length < 3) {
    return "Reason for visit is too short.";
  }

  const appointmentDate = new Date(appointmentDateTime);

  if (isNaN(appointmentDate.getTime())) {
    return "Invalid appointment date and time.";
  }

  if (appointmentDate <= new Date()) {
    return "Appointment date and time must be in the future.";
  }

  return null;
}

function validateAuthorizationPin(authorizationPin) {
  return authorizationPin === VALID_APPOINTMENT_AUTHORIZATION_PIN;
}

function scheduleAppointment(user, patientId, doctorId, appointmentDateTime, reason, authorizationPin) {
  if (!user) {
    logRequest(null, patientId, "Failed - Not Authenticated");
    return {
      success: false,
      message: "User must be logged in."
    };
  }

  if (user.role !== "Patient" && user.role !== "Receptionist") {
    logRequest(user.user_id, patientId, "Failed - Unauthorized Role");
    return {
      success: false,
      message: "Access denied. Only patients or receptionists can schedule appointments."
    };
  }

  if (!validateAuthorizationPin(authorizationPin)) {
    logRequest(user.user_id, patientId, "Failed - Invalid Authorization PIN");
    return {
      success: false,
      message: "Invalid authorization PIN."
    };
  }

  if (!checkRateLimit(user.user_id)) {
    logRequest(user.user_id, patientId, "Failed - Rate Limit Exceeded");
    return {
      success: false,
      message: "Too many appointment requests. Please wait before trying again."
    };
  }

  const validationError = validateAppointmentData(
    patientId,
    doctorId,
    appointmentDateTime,
    reason
  );

  if (validationError) {
    logRequest(user.user_id, patientId, "Failed - Invalid Input");
    return {
      success: false,
      message: validationError
    };
  }

  const patient = patients.find(p => p.patient_id === patientId);

  if (!patient) {
    logRequest(user.user_id, patientId, "Failed - Invalid Patient");
    return {
      success: false,
      message: "Patient does not exist."
    };
  }

  const doctor = doctors.find(d => d.doctor_id === doctorId);

  if (!doctor) {
    logRequest(user.user_id, patientId, "Failed - Invalid Doctor");
    return {
      success: false,
      message: "Doctor does not exist."
    };
  }

  if (!doctor.available) {
    logRequest(user.user_id, patientId, "Failed - Doctor Unavailable");
    return {
      success: false,
      message: "Doctor is unavailable."
    };
  }

  const duplicateAppointment = appointments.find(
    appointment =>
      appointment.doctor_id === doctorId &&
      appointment.appointment_datetime === appointmentDateTime
  );

  if (duplicateAppointment) {
    logRequest(user.user_id, patientId, "Failed - Time Slot Booked");
    return {
      success: false,
      message: "Appointment time already booked."
    };
  }

  const newAppointment = {
    appointment_id: appointments.length + 1,
    patient_id: patientId,
    doctor_id: doctorId,
    scheduled_by_user_id: user.user_id,
    appointment_datetime: appointmentDateTime,
    reason,
    status: "Confirmed",
    created_at: new Date().toISOString()
  };

  appointments.push(newAppointment);

  logRequest(user.user_id, patientId, "Success");

  return {
    success: true,
    message: "Appointment scheduled successfully.",
    appointment: newAppointment
  };
}

module.exports = {
  validateAuthorizationPin,
  scheduleAppointment
};
