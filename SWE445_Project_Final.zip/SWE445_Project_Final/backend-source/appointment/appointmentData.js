const users = [
  { user_id: 1, username: "patient1", role: "Patient" },
  { user_id: 2, username: "receptionist1", role: "Receptionist" },
  { user_id: 3, username: "doctor1", role: "Doctor" },
  { user_id: 4, username: "doctor2", role: "Doctor" }
];

const patients = [
  {
    patient_id: 1029,
    user_id: 1,
    full_name: "Nora Alkuwaihes"
  }
];

const doctors = [
  {
    doctor_id: 201,
    user_id: 3,
    full_name: "Dr. Shahad Sulais",
    specialization: "Cardiology",
    available: true
  },
  {
    doctor_id: 202,
    user_id: 4,
    full_name: "Dr. Reem Abdelgawad",
    specialization: "Dermatology",
    available: false
  }
];

const appointments = [
  {
    appointment_id: 1,
    patient_id: 1029,
    doctor_id: 201,
    scheduled_by_user_id: 2,
    appointment_datetime: "2026-04-20T10:00:00",
    reason: "Regular checkup",
    status: "Confirmed"
  }
];

const appointmentRequestLogs = [
  {
    request_log_id: 1,
    user_id: 2,
    patient_id: 1029,
    action_type: "Schedule Appointment",
    outcome_status: "Success"
  }
];

module.exports = {
  users,
  patients,
  doctors,
  appointments,
  appointmentRequestLogs
};
