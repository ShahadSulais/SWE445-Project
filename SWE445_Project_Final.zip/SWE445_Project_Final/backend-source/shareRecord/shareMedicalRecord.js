// shareMedicalRecord.js

import {
  medicalRecords,
  providers,
  sharingConsents,
  auditLogs
} from "./shareData.js";

function isPatient(user) {
  return user.role === "patient";
}

function validRecord(patientId, recordId) {
  return medicalRecords.some(
    r => r.recordId === recordId && r.patientId === patientId
  );
}

function providerExists(providerId) {
  return providers.some(p => p.providerId === providerId);
}

function isDuplicate(patientId, recordId, providerId) {
  return sharingConsents.some(c =>
    c.patientId === patientId &&
    c.recordId === recordId &&
    c.providerId === providerId
  );
}

function verifyOTP(code) {
  return code === "123456";
}

export function shareMedicalRecord(
  user,
  patientId,
  recordId,
  providerId,
  consent,
  otpCode,
  durationHours
) {
  if (!user || !patientId || !recordId || !providerId) {
    return { status: "error", message: "Invalid input" };
  }

  if (!isPatient(user)) {
    return { status: "error", message: "Only patient can share" };
  }

  if (!providerExists(providerId)) {
    return { status: "error", message: "Provider not found" };
  }

  if (!validRecord(patientId, recordId)) {
    return { status: "error", message: "Invalid record" };
  }

  if (!verifyOTP(otpCode)) {
    return { status: "error", message: "OTP failed" };
  }

  if (!consent) {
    return { status: "error", message: "No consent" };
  }

  if (isDuplicate(patientId, recordId, providerId)) {
    return { status: "error", message: "Duplicate sharing" };
  }

  const consentRecord = {
    consentId: "C" + (sharingConsents.length + 1),
    patientId,
    recordId,
    providerId,
    consentStatus: "approved",
    consentedAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + durationHours * 3600000)
  };

  sharingConsents.push(consentRecord);

  auditLogs.push({
    action: "SHARE_RECORD",
    user: user.username,
    recordId,
    providerId,
    time: new Date().toISOString()
  });

  return {
    status: "success",
    message: "Record shared",
    data: consentRecord
  };
}